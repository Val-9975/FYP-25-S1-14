import uuid
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import make_password
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from .models import MerchantTransaction, LegacyUser, Transaction, Complaint
from .login import authenticate_user
from .verifyOTP import verify_otp_user
from .logout import custom_logout
from .forms import ComplaintForm

def create_user(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        phone_number = request.POST.get('phone_number')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        country = request.POST.get('country')
        zip_code = request.POST.get('zip_code')

        # Set role_id based on user type (Customer: 1, Merchant: 2)
        role_id = request.POST.get('role')  # Get role_id from form input
        
        try:
            role_id = int(role_id)  # Convert to integer
        except ValueError:
            messages.error(request, "Invalid Role ID")
            return render(request, 'createUsers.html', {'email': email, 'first_name': first_name, 'last_name': last_name, 'phone_number': phone_number, 'address': address, 'city': city, 'state': state, 'country': country, 'zip_code': zip_code})

        status = request.POST.get('status', 'active')  # Default to 'active' if not provided

        # Hash the password before saving (not hashing for now, if not cannot see in database)
        #hashed_password = make_password(password)

        # Create the user and save to the database
        user = LegacyUser(
            email=email,
            password=password, #hashed_password to hash it
            first_name=first_name,
            last_name=last_name,
            phone_number=phone_number,
            address=address,
            city=city,
            state=state,
            country=country,
            zip_code=zip_code,
            role_id=role_id,
            status=status
        )
        user.save()
        messages.success(request, f'User {email} created successfully')
        return redirect('create_user')  # Redirect after successful creation

    return render(request, 'createUsers.html')

def handle_login(request):
    if request.method == "POST":
        if authenticate_user(request):  # Calls function from login.py
            return redirect('verify_otp')
        else:
            messages.error(request, "Invalid email or password.")
            return render(request, 'login.html')

    return render(request, 'login.html')


def verify_otp(request):
    if request.method == "POST":
        redirect_page = verify_otp_user(request)  # Calls function from verify.py
        if redirect_page:
            return redirect(redirect_page)
        else:
            messages.error(request, "Invalid OTP. Please try again.")
            return render(request, 'verify_otp.html')

    return render(request, 'verify_otp.html')

@login_required
def customer_dashboard(request):
    user = request.user

    context = {
        'user_id' : user.pk,
        'email' : user.email,
        'first_name' : user.first_name,
        'last_name' : user.last_name,
        'phone_number' : user.phone_number,
        'address' : user.address,
        'city' : user.city,
        'state' : user.state,
        'country' : user.country,
        'zip_code' : user.zip_code,
    }
    
    return render(request, 'customerUI.html', context)

@login_required
def merchant_dashboard(request) :
    user = request.user #get currently logged in user

    context = {
        'user_id' : user.pk,
        'email' : user.email,
        'first_name' : user.first_name,
        'last_name' : user.last_name,
        'phone_number' : user.phone_number,
        'address' : user.address,
        'city' : user.city,
        'state' : user.state,
        'country' : user.country,
        'zip_code' : user.zip_code,
        #make sure user mode in model.py has these fields

    }
    return render(request, 'merchantUI.html', context)

@login_required
def helpDesk_dashboard(request) :
    user = request.user #get currently logged in user

    context = {
        'user_id' : user.pk,
        'email' : user.email,
        'first_name' : user.first_name,
        'last_name' : user.last_name,
        'phone_number' : user.phone_number,
        'address' : user.address,
        'city' : user.city,
        'state' : user.state,
        'country' : user.country,
        'zip_code' : user.zip_code,
        #make sure user mode in model.py has these fields

    }
    return render(request, 'HelpDeskUI.html', context)

@login_required
def systemAdmin_dashboard(request) :
    user = request.user #get currently logged in user

    context = {
        'user_id' : user.pk,
        'email' : user.email,
        'first_name' : user.first_name,
        'last_name' : user.last_name,
        'phone_number' : user.phone_number,
        'address' : user.address,
        'city' : user.city,
        'state' : user.state,
        'country' : user.country,
        'zip_code' : user.zip_code,
        #make sure user mode in model.py has these fields

    }
    return render(request, 'SysAdminUI.html', context)

@login_required
def process_money_transfer(request):
    if request.method == 'POST':
        # Retrieve data from the form
        merchant_email = request.POST.get('merchant_email')
        amount = request.POST.get('amount')
        #currency = request.POST.get('currency')
        payment_method = request.POST.get('payment_method')
        card_number = request.POST.get('card_number', '')

        # Look up the merchant using the provided email and ensure they are a merchant (role_id = 2)
        merchant = get_object_or_404(LegacyUser, email=merchant_email, role_id=2)

        # Generate a unique transaction number (e.g., a 12-character string)
        transaction_number = str(uuid.uuid4()).replace('-', '')[:12]

        # Create the MerchantTransaction record using the logged-in customer's details
        MerchantTransaction.objects.create(
            merchant=merchant,
            customer_email=request.user.email,
            customer_first_name=request.user.first_name,
            customer_last_name=request.user.last_name,
            transaction_number=transaction_number,
            amount_sent=amount,
            payment_method=payment_method,
            phone_number=request.user.phone_number,
            address=request.user.address,
            city=request.user.city,
            state=request.user.state,
            country=request.user.country
        )

        # Redirect to a success page or purchase view after processing
        return redirect('view_purchase')
    else:
        return redirect('customer_dashboard')

def process_payment(request):
    # Placeholder logic; replace with your actual payment processing code.
    return render(request, 'process_payment.html')

def transaction_status(request, transaction_id):
    # Retrieve the transaction with the given transaction_id
    transaction = get_object_or_404(Transaction, transaction_id=transaction_id)
    return render(request, 'transaction_status.html', {'transaction': transaction})

def user_transactions(request):
    # Ensure the user is authenticated (you can add @login_required decorator if needed)
    transactions = Transaction.objects.filter(user=request.user)
    return render(request, 'user_transactions.html', {'transactions': transactions})

def custom_logout(request):
    # Django will handle session clearing automatically when calling logout()
    logout(request)
    return redirect('handle_login')  # Redirect to login page after logout


@login_required
def view_purchase(request):
    # Filter by the logged-in customer's email
    user_email = request.user.email
    # Get all rows in merchant_transactions for this customer's email
    purchases = MerchantTransaction.objects.filter(customer_email=user_email)

    return render(request, 'viewPurchaseUI.html', {'transactions': purchases})

def customer_ui(request):
    return render(request, 'customerUI.html')

def contact_support(request):
    return render(request, 'contact.html')

@login_required
def complaints_view(request):
    # Get the complaints related to the logged-in user
    complaints = Complaint.objects.filter(user=request.user)
    
    # Get a list of user emails, excluding the current user's email
    user_emails = LegacyUser.objects.exclude(email=request.user.email).values_list('email', flat=True)
    
    # Pass the complaints and emails to the template
    context = {
        'complaints': complaints,
        'user_email': request.user.email,
        'user_emails': user_emails,
    }
    
    return render(request, 'complaints.html', context)


@login_required
def submit_complaint(request):
    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            # Set the complainant (user) to the logged-in user
            complaint = form.save(commit=False)
            complaint.user = request.user  # Automatically set the logged-in user as the complainant
            complaint.save()

            messages.success(request, "Complaint submitted successfully.")
            return redirect('complaints_view')  # Or wherever you want to redirect after success
    else:
        form = ComplaintForm()

    return render(request, 'complaints.html', {'form': form})

@login_required
def view_submitted_complaints(request):
    role_id = request.user.role_id  
    # Fetch complaints for the currently logged-in user
    complaints = Complaint.objects.filter(user=request.user)
    
    return render(request, 'viewSubmittedComplaints.html', {'role_id': role_id, 'complaints': complaints})