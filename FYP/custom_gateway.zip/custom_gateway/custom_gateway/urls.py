from django.urls import path, include
from django.contrib.auth.views import LogoutView
from payments import views as payment_views

urlpatterns = [
    path('login/', payment_views.custom_login, name='custom_login'),
    path('logout/', LogoutView.as_view(next_page='/login/'), name='logout'),
    path('payments/', include('payments.urls')),
]
