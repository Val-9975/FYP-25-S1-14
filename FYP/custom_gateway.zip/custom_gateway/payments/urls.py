from django.urls import path
from . import views

urlpatterns = [
    path('pay/', views.process_payment, name='process_payment'),
    path('my-transactions/', views.user_transactions, name='user_transactions'),
    # Add the customer dashboard URL:
    path('dashboard/customer/', views.customer_dashboard, name='customer_dashboard'),
]
