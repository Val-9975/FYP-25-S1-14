from django.urls import path
from . import views

urlpatterns = [
    path('pay/', views.process_payment, name='process_payment'),
    path('status/<str:transaction_id>/', views.transaction_status, name='transaction_status'),
]
