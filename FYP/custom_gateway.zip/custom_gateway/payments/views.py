import random
import string
from django.shortcuts import render, redirect
from .forms import PaymentForm
from .models import Transaction
from django.contrib.auth.decorators import login_required

def generate_transaction_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))

@login_required
def process_payment(request):
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            card_number = form.cleaned_data['card_number']
            amount = form.cleaned_data['amount']
            transaction_id = generate_transaction_id()
            
            # Simulate success/failure
            status = 'success' if card_number.endswith('0') else 'failed'

            transaction = Transaction.objects.create(
                user=request.user,
                amount=amount,
                card_number=card_number,
                transaction_id=transaction_id,
                status=status,
            )
            return redirect('transaction_status', transaction_id=transaction.transaction_id)
    else:
        form = PaymentForm()
    
    return render(request, 'process_payment.html', {'form': form})

@login_required
def transaction_status(request, transaction_id):
    transaction = Transaction.objects.get(transaction_id=transaction_id)
    return render(request, 'transaction_status.html', {'transaction': transaction})
