from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .models import Transaction

def custom_login(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            # Redirect based on the user's role_id
            if user.role_id == 1:
                return redirect('customer_dashboard')
            elif user.role_id == 2:
                return redirect('merchant_dashboard')    # Define merchant_dashboard view/URL similarly
            elif user.role_id == 3:
                return redirect('admin_dashboard')       # Define admin_dashboard view/URL similarly
            elif user.role_id == 4:
                return redirect('helpdesk_dashboard')    # Define helpdesk_dashboard view/URL similarly
            else:
                # Fallback redirect if role doesn't match any known role_id
                return redirect('home')
        else:
            messages.error(request, "Invalid email or password.")
    return render(request, 'login.html')

def process_payment(request):
    # Placeholder logic; replace with your actual payment processing code.
    return render(request, 'process_payment.html')

def transaction_status(request, transaction_id):
    # Retrieve the transaction with the given transaction_id
    transaction = get_object_or_404(Transaction, transaction_id=transaction_id)
    return render(request, 'transaction_status.html', {'transaction': transaction})

def user_transactions(request):
    # Ensure the user is authenticated (you can add @login_required decorator if needed)
    transactions = Transaction.objects.filter(user=request.user)
    return render(request, 'user_transactions.html', {'transactions': transactions})

def customer_dashboard(request):
    # This view renders the customer dashboard (customerUI.html)
    return render(request, 'customerUI.html')